import struct, zlib, os

os.makedirs(r'F:\Cherry Studio Agent\MoeKoeMusic-download-plugin\icons', exist_ok=True)

def create_png(width, height, color=(64, 96, 255)):
    def chunk(chunk_type, data):
        c = chunk_type + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)

    header = b'\x89PNG\r\n\x1a\n'
    ihdr = chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))

    raw = b''
    for y in range(height):
        raw += b'\x00'
        for x in range(width):
            cx = x / max(width - 1, 1)
            cy = y / max(height - 1, 1)
            r = int(color[0] * (1 - 0.3 * cx) * (1 - 0.2 * cy))
            g = int(color[1] * (1 - 0.3 * cy))
            b = int(color[2] * (1 - 0.2 * cx))
            raw += struct.pack('BBB', r, g, b)

    idat = chunk(b'IDAT', zlib.compress(raw))
    iend = chunk(b'IEND', b'')
    return header + ihdr + idat + iend

for size, name in [(16, '16'), (48, '48'), (128, '128')]:
    path = r'F:\Cherry Studio Agent\MoeKoeMusic-download-plugin\icons\icon{}.png'.format(name)
    with open(path, 'wb') as f:
        f.write(create_png(size, size))
    print(f'Created: {path} ({os.path.getsize(path)} bytes)')

print('All icons created successfully')
