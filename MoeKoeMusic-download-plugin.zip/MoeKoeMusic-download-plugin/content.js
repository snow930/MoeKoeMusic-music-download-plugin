(function () {
  'use strict';

  if (window.__MOEKOE_DOWNLOAD__) return;
  window.__MOEKOE_DOWNLOAD__ = true;

  var toastTimer = null;
  var isDownloading = false;

  function getCurrentSong() {
    try {
      return JSON.parse(localStorage.getItem('current_song') || '{}');
    } catch (e) {
      return {};
    }
  }

  function sanitizeFilename(name) {
    return name.replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, ' ').trim();
  }

  function getFileExtension(url) {
    try {
      var path = url.split('?')[0].split('#')[0];
      var ext = path.split('.').pop().toLowerCase();
      if (ext && ext.length <= 5 && /^[a-z0-9]+$/.test(ext)) return ext;
    } catch (e) {}
    return 'mp3';
  }

  function showToast(msg, duration) {
    duration = duration || 2500;
    var toast = document.querySelector('.moekoe-download-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'moekoe-download-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.style.opacity = '0';
    }, duration);
  }

  async function downloadCurrentSong(btn) {
    if (isDownloading) return;
    isDownloading = true;
    btn.classList.add('downloading');

    var song = getCurrentSong();
    if (!song.url) {
      showToast('暂无音频 URL，请先播放歌曲');
      btn.classList.remove('downloading');
      isDownloading = false;
      return;
    }

    var title = song.title || song.name || song.songName || song.songname || song.filename || '未知歌曲';
    var artist = song.artist || song.singer || song.author || song.singername || song.singerName || song.author_name || '';
    var album = song.album || song.albumName || song.album_name || '';
    var ext = getFileExtension(song.url);
    var filename = sanitizeFilename(artist ? artist + ' - ' + title : title) + '.' + ext;

    showToast('正在下载: ' + filename, 0);

    try {
      var response = await fetch(song.url);
      if (!response.ok) {
        throw new Error('HTTP ' + response.status);
      }

      var contentLength = response.headers.get('Content-Length');
      var total = contentLength ? parseInt(contentLength, 10) : 0;
      var loaded = 0;

      var reader = response.body.getReader();
      var chunks = [];

      while (true) {
        var result = await reader.read();
        if (result.done) break;
        chunks.push(result.value);
        loaded += result.value.length;
        if (total > 0) {
          var pct = Math.round(loaded / total * 100);
          showToast('下载中: ' + filename + ' (' + pct + '%)', 0);
        }
      }

      var blob = new Blob(chunks);
      var blobUrl = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setTimeout(function () { URL.revokeObjectURL(blobUrl); }, 1000);

      // 格式化文件大小
      var sizeText = '';
      if (blob.size >= 1024 * 1024) {
        sizeText = (blob.size / 1024 / 1024).toFixed(1) + 'MB';
      } else {
        sizeText = (blob.size / 1024).toFixed(0) + 'KB';
      }
      showToast('下载完成: ' + filename + ' (' + sizeText + ')');
    } catch (err) {
      console.error('[Download] 下载失败:', err);
      showToast('下载失败: ' + err.message);
    }

    btn.classList.remove('downloading');
    isDownloading = false;
  }

  function createDownloadButton() {
    var extraControls = document.querySelector('.extra-controls');
    if (!extraControls) return;

    if (document.querySelector('.moekoe-download')) return;

    var btn = document.createElement('div');
    btn.className = 'extra-btn moekoe-download';
    btn.title = '下载当前歌曲';
    btn.innerHTML = '<i class="fa fa-download" aria-hidden="true"></i>';
    btn.addEventListener('click', function () {
      downloadCurrentSong(btn);
    });

    extraControls.appendChild(btn);
  }

  function init() {
    createDownloadButton();

    var observer = new MutationObserver(function () {
      var extraControls = document.querySelector('.extra-controls');
      if (extraControls && !document.querySelector('.moekoe-download')) {
        createDownloadButton();
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
